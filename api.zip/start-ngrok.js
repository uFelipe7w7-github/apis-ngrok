const ngrok = require('ngrok');
const express = require('express');
require('dotenv').config(); // Carrega variáveis de ambiente do arquivo .env

const port = process.env.PORT || 3000;
const app = express();

// Função para iniciar o servidor com Ngrok e configurar o authtoken
async function startServerWithNgrok() {
    try {
        // Configura o authtoken do Ngrok a partir do .env
        await ngrok.authtoken(process.env.NGROK_AUTHTOKEN);

        // Conecta o servidor à porta configurada
        const url = await ngrok.connect(port);
        console.log(`Ngrok URL: ${url}`);

        // Inicia o servidor Express
        app.listen(port, () => {
            console.log(`Servidor rodando na porta ${port}`);
            console.log(`API exposta em: ${url}`);
        });
    } catch (error) {
        console.error('Erro ao iniciar o Ngrok:', error);
    }
}

// Inicia o servidor com Ngrok
startServerWithNgrok();