# API com Integração Ngrok e Consultas

Este projeto é uma API em Node.js que permite consultas de CPF, BIN, Nome, Telefone, Placa e Foto RJ, com suporte para desenvolvimento local utilizando **Ngrok**.

## Configuração

### 1. Instalar Dependências

```bash
npm install