// Importação de módulos
const express = require('express');
const axios = require('axios');
require('dotenv').config(); // Carrega as variáveis de ambiente do .env

const app = express();
const PORT = process.env.PORT || 3000;

// Função para fazer requisições às APIs
async function fetchFromAPI(url) {
    try {
        const response = await axios.get(url);
        return response.data;
    } catch (error) {
        console.error(`Erro ao buscar dados da API: ${error}`);
        return { error: 'Erro ao buscar dados' };
    }
}

// Endpoint para CPF
app.get('/cpf/:cpf', async (req, res) => {
    const { cpf } = req.params;
    const url = `${process.env.API_URL_CPF}?cpf=${cpf}&apikey=${process.env.API_KEY}`;
    const data = await fetchFromAPI(url);
    res.json(data);
});

// Endpoint para BIN
app.get('/bin/:bin', async (req, res) => {
    const { bin } = req.params;
    const url = `${process.env.API_URL_BIN}?bin=${bin}&apikey=${process.env.API_KEY}`;
    const data = await fetchFromAPI(url);
    res.json(data);
});

// Endpoint para Nome
app.get('/nome/:name', async (req, res) => {
    const { name } = req.params;
    const url = `${process.env.API_URL_NAME}?name=${encodeURIComponent(name)}&apikey=${process.env.API_KEY}`;
    const data = await fetchFromAPI(url);
    res.json(data);
});

// Endpoint para Telefone
app.get('/telefone/:phone', async (req, res) => {
    const { phone } = req.params;
    const url = `${process.env.API_URL_PHONE}?phone=${phone}&apikey=${process.env.API_KEY}`;
    const data = await fetchFromAPI(url);
    res.json(data);
});

// Endpoint para Placa
app.get('/placa/:plate', async (req, res) => {
    const { plate } = req.params;
    const url = `${process.env.API_URL_PLATE}?plate=${plate}&apikey=${process.env.API_KEY}`;
    const data = await fetchFromAPI(url);
    res.json(data);
});

// Endpoint para Foto RJ (com CPF)
app.get('/fotorj/:cpf', async (req, res) => {
    const { cpf } = req.params;
    const url = `${process.env.API_URL_FOTORJ}?cpf=${cpf}&apikey=${process.env.API_KEY}`;
    const data = await fetchFromAPI(url);
    res.json(data);
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});